package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import VO.TeachersVO;


public class TeahcersDAO {


	public Connection getConnection() throws Exception {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String pw="kh";
		String id="kh";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		return DriverManager.getConnection(url, id, pw);
	}

	
	
	public String logIn(String id, String pw) throws Exception {
		
		
		String sql="select name from teachers where id=? and pw=?";
		String name = null;
		try(
		Connection con=getConnection();
		PreparedStatement pstat=con.prepareStatement(sql);
		){
			pstat.setString(1, id);
			pstat.setString(2, pw);
			//1. ResultSet�� ���� try-with-resourse.
			try(
			ResultSet rs=pstat.executeQuery();
				){
				while(rs.next()) {
					//2. name return������ ������ ���� rs.next(); 
					name=rs.getString(1);
					//3. con.commit();
				}
				//4. ��ϵ� ���̵� ���ٸ� null �ִٸ�, �ش� �̸��� ��µȴ�.
				return name;
			}
		}
		}
	
	public boolean idCheck(String targetID) throws Exception {
		
		
		String sql="select * from teachers where id=?";
		boolean result;
		try(
		Connection con=getConnection();
		PreparedStatement pstat=con.prepareStatement(sql);
		){
			pstat.setString(1, targetID);
			try(
				ResultSet rs=pstat.executeQuery();
				){
					result=rs.next();
					return result;
					
				}
		}
	}
	
	
	
	public int insertData(TeachersVO vo) throws Exception {
		
		
		int result=0;
		String sql="insert into teachers values (teachers_seq.nextval, ?,?,?,sysdate)";
		try(
		Connection con=getConnection();
		PreparedStatement pstat=con.prepareStatement(sql);
		){
			pstat.setString(1, vo.getId());
			pstat.setString(2, vo.getPw());
			pstat.setString(3, vo.getName());
			result=pstat.executeUpdate();
			con.commit();
		}
	return result;
	}
	
	
}
