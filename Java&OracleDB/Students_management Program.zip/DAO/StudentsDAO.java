package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import VO.StudentsVO;
import VO.TeachersVO;

public class StudentsDAO {
	
	public Connection getConnection() throws Exception, Exception {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user="kh";
		String password="kh";
		return DriverManager.getConnection(url, user, password);
	}
	
	public int insertData(StudentsVO vo) throws Exception {
		
	
		String sql="insert into students values (students_seq.nextval,?,?,?,?,?)";
		//**���������� column���� sequence�� Ȯ���ϰ� �Է��ϱ�.
		int result=0;
		try(
		Connection con=getConnection();
		PreparedStatement pstat=con.prepareStatement(sql);
		){pstat.setString(1, vo.getTeachersId());
		  //���� vo��ü�κ��� �� ���� ���Թ޾ƿ;� �Ѵ�.
		  pstat.setString(2, vo.getStName());
		  pstat.setInt(3, vo.getKor());
	      pstat.setInt(4, vo.getEng());
	      pstat.setInt(5, vo.getMath());
		  result=pstat.executeUpdate();

		  
		  con.commit();	
		}
		return result;
	  }
	
	public List<StudentsVO> ListAll() throws Exception {
		
		String sql= "select" + 
				"				seq," + 
				"				name," + 
				"				kor," + 
				"				eng," + 
				"             	math,"+ 
				"              	(kor+eng+math)," + 
				"				round((kor+eng+math)/3,2)," + 
				"				row_number()over(order by round((kor+eng+math)/3,2) desc)" + 
				"				from students order by 8";
		List<StudentsVO> result=new ArrayList<>();
		try(
		Connection con=getConnection();
		PreparedStatement pstat=con.prepareStatement(sql);
		ResultSet rs=pstat.executeQuery();		
		){
			while(rs.next()) {
				  result.add(new StudentsVO(
				  rs.getInt(1),	
				  rs.getString(2),
				  rs.getInt(3),
				  rs.getInt(4),
				  rs.getInt(5),
				  rs.getInt(6),
				  rs.getInt(7),
				  rs.getInt(8)));}
		}
		return result;		
		}
	
	public int updateData(int kor, int eng, int math, int seq) throws Exception {
		
		String sql="update students set kor=?, eng=?, math=? where seq=?";
		//*where ������ ���� ������ �� �� and�� ����.
		int result;
		try(Connection con=getConnection();
			PreparedStatement pstat=con.prepareStatement(sql);	
			){pstat.setInt(1, kor);
			  pstat.setInt(2, eng);
			  pstat.setInt(3, math);
			  pstat.setInt(4, seq);
			  result=pstat.executeUpdate();
			  con.commit();}
		return result;
		}
	
	public boolean checkID(int seq) throws Exception {
		
		String sql="select * from students where seq=?";
		boolean result;
		try(Connection con=getConnection();
			PreparedStatement pstat=con.prepareStatement(sql);	
			){pstat.setInt(1, seq);
				try(ResultSet rs=pstat.executeQuery();){
					result=rs.next();}}
		return result;
		}
			
	public int deleteData(int seq) throws Exception {
		
		String sql="delete from students where seq=?";
		//*where ������ ���� ������ �� �� and�� ����.
		int result;
		try(Connection con=getConnection();
			PreparedStatement pstat=con.prepareStatement(sql);	
			){pstat.setInt(1, seq);
			  result=pstat.executeUpdate();
			  con.commit();}
		return result;
		}
	
	public List<StudentsVO> printRank() throws Exception {
		
		String sql="select" + 
				"    s.name," + 
				"    (kor+eng+math)," + 
				"    round((kor+eng+math)/3, 2)," + 
				"    row_number()over(order by round((kor+eng+math)/3, 2) desc)," + 
				"    t.name" + 
				"    from students s, teachers t" +
				"	 where s.teacher=t.id";
		List<StudentsVO> result=new ArrayList<>();
		try(Connection con=getConnection();
			PreparedStatement pstat=con.prepareStatement(sql);
			ResultSet rs=pstat.executeQuery();)
			{while(rs.next()) {
				result.add(new StudentsVO(
							rs.getString(1),
							rs.getInt(2),
							rs.getInt(3),
							rs.getInt(4),
							rs.getString(5)));}
		}
		return result;	
		}
	
	

}
