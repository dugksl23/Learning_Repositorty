package VO;

import java.security.Timestamp;

public class TeachersVO {

	
	private int seq;
	private String id;
	private String pw;
	private String name;
	private Timestamp reg_date;
	
	
	
	public TeachersVO() {}
	
	//1. ID, PW, Name�� �Է¹��� �����ڸ� �������Ѵ�.
	public TeachersVO(int seq, String id, String pw, String name, Timestamp reg_date) {
		super();
		this.seq = seq;
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.reg_date = reg_date;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	
	
	
	
	
	
}
