package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbcp2.BasicDataSource;

import VO.membersVO;

public class membersDAO {

	// 0. main에 내보낼 connection pool 인스턴스이며, main과 함께할 
	//    return 메소드이기에 static
	private static membersDAO instance;
	// 1.DBCP 구동을 위한 객체 생성
	private BasicDataSource bds=new BasicDataSource();

	// 2. DBCP 객체를 통한 JDBC 드라이버 로드 및 DAO생성자를 통해 MAIN과 함께 연결값 셋팅. 
	// 3. DAO의 NEW를 방지
	private membersDAO(){
		bds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		bds.setUsername("tester");
		bds.setPassword("tester");
		bds.setInitialSize(5);
	}


	// 3. MAIN에서 NEW할 수 없기에 Connection 기능을 수행할 single turn patton.
	public synchronized static membersDAO getInstance() {

		if(instance==null) {
			instance=new membersDAO();
		}
		return instance;	
	}

	// 4. 메소드별 기능을 수행할 때 연결을 위한 getConnection
	public Connection getConnection() throws SQLException {
		return bds.getConnection();
	}



	public int insertData(membersVO vo) throws Exception {

		int result;
		String sql="insert into members values (members_seq.nextval, ?,?,?,?,?,sysdate, ?, 'Y')";
		try(
				Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){pstat.setString(1, vo.getId());
				pstat.setString(2, vo.getPw());
				pstat.setString(3, vo.getName());
				pstat.setString(4, vo.getDept_code());
				pstat.setString(5, vo.getJob_code());
				pstat.setInt(6, vo.getSalary());
				result=pstat.executeUpdate();
				con.commit();
		}
		return result;	
	}


	public boolean checkId(String targetId) throws Exception {

		boolean result;
		String sql="select name from members where id=?";
		try(Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){pstat.setNString(1, targetId);
				try(ResultSet rs=pstat.executeQuery();){
					result=rs.next();
				}
		}
		return result;	
	}


	public membersVO getLogin(String id, String pw) throws SQLException {


		membersVO vo=new membersVO(); 
		String sql="select name, job_name from members m, job j where m.job_code=j.job_code and id=? and pw=?";
		try(Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){pstat.setString(1, id);
				pstat.setString(2, pw);

				try(ResultSet rs=pstat.executeQuery();){
					while(rs.next()) {
						vo.setName(rs.getString(1));
						vo.setJob_name(rs.getString(2));
					}
				}
		}
		return vo;
	}



	public List<membersVO> selectMyInfo(String id) throws SQLException {

		List<membersVO> result = new ArrayList<>();
		String sql="select m.seq, id, name, dept_title, job_name, hire_date, to_char(salary, 'l999,999,999') from members m, department d, job j where m.job_code=j.job_code and m.dept_code=d.dept_code and id=?";
		try(Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){pstat.setString(1, id);
				try(ResultSet rs=pstat.executeQuery();){
					while(rs.next()) {
						result.add(new membersVO(
								rs.getInt(1),
								rs.getString(2), 
								rs.getString(3),
								rs.getString(4),
								rs.getString(5),
								rs.getTimestamp(6),
								rs.getString(7)
								));
					}
				}
		}
		return result;
	}
	
	
	public List<membersVO> selectAll() throws Exception {
		List<membersVO> result = new ArrayList<>();
		String sql="select m.seq, id, name, dept_title, job_name, hire_date, to_char(salary, 'l999,999,999') from members m, department d, job j where m.job_code=j.job_code and m.dept_code=d.dept_code";
		try(Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){try(ResultSet rs=pstat.executeQuery();){
					while(rs.next()) {
						result.add(new membersVO(
								rs.getInt(1),
								rs.getString(2), 
								rs.getString(3),
								rs.getString(4),
								rs.getString(5),
								rs.getTimestamp(6),
								rs.getString(7)
								));
					}
				}
		}
		return result;
	}


	public boolean getWithdraw(String id) throws Exception {
		
		boolean result;
		String sql="update members set on_work='N' where id=?";
		try(Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){pstat.setNString(1, id);
				try(ResultSet rs=pstat.executeQuery();){
					result=rs.next();
				}
		}
		return result;	
		
	}





}
