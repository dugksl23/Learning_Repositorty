package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbcp2.BasicDataSource;

import VO.MessagesVO;


public class messagesDAO {

	private static messagesDAO instance;
	// 1.DBCP 구동을 위한 객체 생성
	private BasicDataSource bds=new BasicDataSource();

	// 2. DBCP 객체를 통한 JDBC 드라이버 로드 및 DAO생성자를 통해 MAIN과 함께 연결값 셋팅. 
	// 3. DAO의 NEW를 방지
	private messagesDAO(){
		bds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		bds.setUsername("tester");
		bds.setPassword("tester");
		bds.setInitialSize(5);
	}


	// 3. MAIN에서 NEW할 수 없기에 Connection 기능을 수행할 single turn patton.
	public synchronized static messagesDAO getInstance() {

		if(instance==null) {
			instance=new messagesDAO();
		}
		return instance;	
	}

	// 4. 메소드별 기능을 수행할 때 연결을 위한 getConnection
	public Connection getConnection() throws SQLException {
		return bds.getConnection();
	}



	public int writeMessage(MessagesVO vo) throws Exception {

		int result;
		String sql="insert into messages values (messages_seq.nextval, ?,?,?,sysdate,?,?)";
		try(
				Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){pstat.setNString(1, vo.getSender());
				pstat.setString(2, vo.getReceiver());
				pstat.setString(3, vo.getContents());
				pstat.setString(4, vo.getSendername());
				pstat.setString(5, vo.getReceivername());
				result=pstat.executeUpdate();
				con.commit();
		}
		return result;	
	}

	public String getReceiverName(String receiver) throws Exception {
		String name = null;
		String sql="select name from members where id=?";
		try(Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){pstat.setString(1, receiver);
				try(ResultSet rs=pstat.executeQuery()){
					while(rs.next()) {
						name=rs.getString(1);
					}
					con.commit();
				}
		}

		return name;	
	}



	public List<MessagesVO> checkMailbox(int seq) throws SQLException {

		List<MessagesVO> result=new ArrayList<>();
		String sql="select ms.seq, m.name, d.dept_title, m1.name, d1.dept_title, ms.WRITE_DATE" + 
				"				from members m, department d, members m1, department d1, messages ms" + 
				"				where d.dept_code=m.dept_code and" + 
				"				d1.dept_code=m1.dept_code and" + 
				"				m.name!=m1.name and" + 
				"				ms.seq=? and" + 
				"				(m.name, m1.name, d.dept_title, d1.dept_title, ms.seq) in" + 
				"				(select sendername, receivername, d.dept_title, d1.dept_title, seq" + 
				"				from messages, department d, department d1) order by seq";
		try(Connection con=getConnection();
				PreparedStatement pstat=con.prepareStatement(sql);
				){pstat.setInt(1, seq);
				try(ResultSet rs=pstat.executeQuery()){
					while(rs.next()) {
						result.add(new MessagesVO(
								rs.getInt(1),
								rs.getString(2),
								rs.getString(3),
								rs.getString(4),
								rs.getString(5),
								rs.getTimestamp(6)));
					}
				}
				return result;	
		}
	}


}