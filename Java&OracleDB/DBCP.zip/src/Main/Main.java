package Main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import DAO.membersDAO;
import DAO.messagesDAO;
import Units.CodePassword;
import VO.MessagesVO;
import VO.membersVO;



public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		membersVO mVO=new membersVO();
		membersDAO mDAO = membersDAO.getInstance();

		menu:while(true) {	
			System.out.println("<< Groupware Login >>\r"
					+ "1. 회원 가입\r"
					+ "2. 로그인\r"
					+ ">> ");

			int menu=Integer.parseInt(sc.nextLine());
			String id, pw, name = null, dept_code, job_code;
			int salary = 0, result;
			if(!(menu>0&&menu<3)) {continue menu;}

			switch(menu) {
			case 1:
				System.out.print("ID: ");
				id=sc.nextLine();

				try {
					if(mDAO.checkId(id)){
						System.out.println("등록된 ID입니다.\r 다른 ID를 사용해세요.");
						continue menu;}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.print("pw: ");
				pw=CodePassword.getSHA256(sc.nextLine());	
				System.out.println("이름 : ");
				name=sc.nextLine();
				dept_code="D"+(int)(Math.random()*4+1);
				job_code="J"+(int)(Math.random()*6+1);
				System.out.println("salary : ");
				salary=Integer.parseInt(sc.nextLine());


				mVO=new membersVO(0, id,pw, name, dept_code, job_code, salary);
				try {
					result=mDAO.insertData(mVO);
				} catch (Exception e) {
					System.out.println("Erro 발생\r 관리자에게 문의 요망");
					e.printStackTrace();
					continue menu;
				}

				if(result==0) {
					System.out.println("입력 실패");
					continue menu;
				}else {
					System.out.println("입력 성공");
					continue menu;
				}

			case 2:

				System.out.print("ID : ");
				id=sc.nextLine();
				System.out.println("PW : ");
				pw=CodePassword.getSHA256(sc.nextLine());

				try {
					mVO=mDAO.getLogin(id, pw);
					name=mVO.getName();
					String job_name=mVO.getJob_name();

					if(name==null) {
						System.out.println("ID 또는 PW가 일치하지 않습니다.\r확인 후 다시 입력해주세요.");
						continue menu;}

					for(int i=0; i<1; i++) {
						System.out.println(name+"["+job_name+"] 님 환영합니다.");}
				} catch (SQLException e) {
					System.out.println("Erro 발생\r 관리자에게 문의 요망");
					e.printStackTrace();
				}




				//===== << Group Messanger >> === 

				MessagesVO msVO=new MessagesVO();
				messagesDAO msDAO=messagesDAO.getInstance();
				messanger_menu:while(true) {	
					System.out.print("<< Group Messanger >>\r"
							+ "1. 내 정보 보기\r"
							+ "2. 직원 명단 보기\r"
							+ "3. 메세지 함 보기\r"
							+ "4. 메세지 보내기\r"
							+ "5. 탈퇴하기\r"
							+ "6. 종료하기\r"
							+ ">> ");
					menu=Integer.parseInt(sc.nextLine());

					if(!(menu>0&&menu<7)) {
						System.out.println("입력 범위 초과");
						continue messanger_menu;}

					switch(menu) {
					case 1:
						List<membersVO> list = null;
						try {
							list = mDAO.selectMyInfo(id);
						} catch (Exception e) {
							System.out.println("Erro 발생\r 관리자에게 문의 요망");
							e.printStackTrace();
						}
						for(membersVO vo:list) {
							System.out.printf("사원번호 : %d\tID: %s\t이름 : %s\t부서명 : %s\t직급명 : %s\t고용일 : %s\t월급 :%s\r",
									vo.getSeq(),vo.getId(),vo.getName(),vo.getDept_title(), vo.getJob_name(), vo.getFormadate(), vo.getSalTostr());
							continue messanger_menu;}
					case 2:	
						list = null;
						try {
							list = mDAO.selectAll();
						} catch (Exception e) {
							System.out.println("Erro 발생\r 관리자에게 문의 요망");
							e.printStackTrace();
						}
						for(membersVO vo:list) {
							System.out.printf("사원번호 : %d\tID: %s\t이름 : %s\t부서명 : %s\t직급명 : %s\t고용일 : %s\t월급 :%s\r",
									vo.getSeq(),vo.getId(),vo.getName(),vo.getDept_title(), vo.getJob_name(), vo.getFormadate(), vo.getSalTostr());}
						continue messanger_menu;
					case 3:
						System.out.print("검색할 쪽지 번호 : ");
						int seq=Integer.parseInt(sc.nextLine());
						List<MessagesVO> list2;
						try {
							list2=msDAO.checkMailbox(seq);
							
							for(MessagesVO e:list2) {
								System.out.printf("쪽지번호 : %d\t보낸이: %s\t부서명 : %s\t받는이: %s\t부서명 : %s\t보낸 시각 : %s\r",
													e.getSeq(),e.getSendername(), e.getSenderDept(), e.getReceivername(), e.getReceiverDept(),e.getFormatDate());
							}
							continue messanger_menu;
						} catch (SQLException e1) {
							System.out.println("Erro 발생\r 관리자에게 문의 요망");
							e1.printStackTrace();
							continue messanger_menu;
						}
					case 4:
						System.out.print("receiver : ");
						String receiver=sc.nextLine();
						System.out.print("contents : ");
						String contents=sc.nextLine();
						String receiverName;
						try {
							receiverName = msDAO.getReceiverName(receiver);
							msVO=new MessagesVO(0, id, receiver, contents, name,receiverName);
							
							
							if(msDAO.writeMessage(msVO)==0) {
								System.out.println("전송 실패");
								continue messanger_menu;
							}else {
								System.out.println("전공 완료");
								continue messanger_menu;
							}
						} catch (Exception e) {
							System.out.println("Erro 발생\r 관리자에게 문의 요망");
							e.printStackTrace();
							continue messanger_menu;
						}
					case 5:
						try {
							
							if(mDAO.getWithdraw(id)) {
								System.out.println("탈퇴되었습니다.");
								continue menu;
							}else {
								System.out.println("탈퇴되지 않았습니다.");
								continue messanger_menu;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					case 6:System.out.println(" << 종료 >>");
					System.exit(0);


					}//messanger switch문 종료
				}//	messanger_menu for문 종료
			}//menu switch 구문 종료
		} // menu for문 종료;
	}
}
