package VO;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class MessagesVO {
	
	private int seq;
	private String sender;
	private String receiver;
	private String contents;
	private Timestamp write_date;
	private String sendername;
	private String receivername;
	private String senderDept;
	private String receiverDept;
	
	
	


	public MessagesVO() {}
	
	
	public MessagesVO(int seq, String sender, String receiver, String contents, String sendername,
			String receivername) {
		super();
		this.seq = seq;
		this.sender = sender;
		this.receiver = receiver;
		this.contents = contents;
		this.sendername = sendername;
		this.receivername = receivername;
	}
	
	
	
	
	
	public MessagesVO(int seq, String sendername, String senderDept, String receivername,
			String receiverDept, Timestamp write_date) {
		super();
		this.seq = seq;
		this.write_date = write_date;
		this.sendername = sendername;
		this.receivername = receivername;
		this.senderDept = senderDept;
		this.receiverDept = receiverDept;
	}


	public String getSenderDept() {
		return senderDept;
	}


	public void setSenderDept(String senderDept) {
		this.senderDept = senderDept;
	}


	public String getReceiverDept() {
		return receiverDept;
	}


	public void setReceiverDept(String receiverDept) {
		this.receiverDept = receiverDept;
	}


	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public Timestamp getWrite_date() {
		return write_date;
	}
	public void setWrite_date(Timestamp write_date) {
		this.write_date = write_date;
	}
	public String getSendername() {
		return sendername;
	}
	public void setSendername(String sendername) {
		this.sendername = sendername;
	}
	public String getReceivername() {
		return receivername;
	}
	public void setReceivername(String receivername) {
		this.receivername = receivername;
	}
	
	
	public String getFormatDate() {
		SimpleDateFormat sdf=new SimpleDateFormat("YYYY년 MM월 dd일 HH시 mm분 ss초");
		return sdf.format(write_date.getTime());
	}
	
	
	
	

}
