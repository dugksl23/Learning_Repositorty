package VO;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class membersVO {
	
	
	private int seq;
	private String id;
	private String pw;
	private String name;
	private String dept_code;
	private String job_code;
	private Timestamp hire_date;
	private int salary;
	private String onWork;
	private String job_name;
	private String dept_title;
	private String salTostr;
	
	// 0. 기본생성자
	public membersVO() {}
	
	// 1.회원가입
	public membersVO(int seq, String id, String pw, String name, String dept_code, String job_code,
			int salary) {
		super();
		this.seq = seq;
		this.id = id;
		this.pw=pw;
		this.name = name;
		this.dept_code = dept_code;
		this.job_code = job_code;
		this.salary = salary;
	}
	
	
	// 2. Messager의 1. 내정보보기

	
	public String getJob_name() {
		return job_name;
	}

	public membersVO(int seq, String id, String name, String dept_title, String job_name, Timestamp hire_date,  
			String salTostr) {
		super();
		this.seq = seq;
		this.id = id;
		this.name = name;
		this.hire_date = hire_date;
		this.job_name = job_name;
		this.dept_title = dept_title;
		this.salTostr = salTostr;
	}

	public String getDept_title() {
		return dept_title;
	}

	public void setDept_title(String dept_title) {
		this.dept_title = dept_title;
	}

	public String getSalTostr() {
		return salTostr;
	}

	public void setSalTostr(String salTostr) {
		this.salTostr = salTostr;
	}


	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}
	
	public String getId() {
		return id;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getDept_code() {
		return dept_code;
	}
	public void setDept_code(String dept_code) {
		this.dept_code = dept_code;
	}
	public String getJob_code() {
		return job_code;
	}
	public void setJob_code(String job_code) {
		this.job_code = job_code;
	}
	public Timestamp getHire_date() {
		return hire_date;
	}
	public void setHire_date(Timestamp hire_date) {
		this.hire_date = hire_date;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getOnWork() {
		return onWork;
	}
	public void setOnWork(String onWork) {
		this.onWork = onWork;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
	
	public String getFormadate() {
		SimpleDateFormat sdf=new SimpleDateFormat("YYYY년 MM월 dd일 HH시 mm분 ss초");		
		return sdf.format(hire_date.getTime());
	}
	
	

}
