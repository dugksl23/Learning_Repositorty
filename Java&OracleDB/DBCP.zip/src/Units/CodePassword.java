package Units;

import java.math.BigInteger;
import java.security.MessageDigest;

public class CodePassword {

	
	//vo에는 클래스의 설계도로서 값을 저장하기 위한 용도이기에 암호화 로직을 vo에 넣는 것은 이상하다.
		// dao 또한 데이터와 관련된 입출력과 관련된 것이기에 이또한 이상하다.
		// main에서는 gui이기에 당연히 이상하다.
		// 이럴 때에는 따로 클래스를 만들어주는 것이 좋다.
		  public static String getSHA256(String input){



		      String toReturn = null;

		      try {

		          MessageDigest digest = MessageDigest.getInstance("SHA-256");

		          digest.reset();

		          digest.update(input.getBytes("utf8"));

		          toReturn = String.format("%064x", new BigInteger(1, digest.digest()));

		      } catch (Exception e) {

		          e.printStackTrace();

		      }

		      

		      return toReturn;
		      // main에서 
		       }

	
}
